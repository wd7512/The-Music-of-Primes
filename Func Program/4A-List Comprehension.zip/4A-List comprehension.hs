

------------------------- Exercise 1

doubles :: [Int] -> [Int]
doubles = undefined

odds :: [Int] -> [Int]
odds = undefined

doubleodds :: [Int] -> [Int]
doubleodds = undefined

shorts :: [String] -> [String]
shorts = undefined

squarePositives :: [Int] -> [Int]
squarePositives = undefined

oddLengthSums :: [[Int]] -> [Int]
oddLengthSums = undefined

remove :: Eq a => [a] -> a -> [a]
remove = undefined

removeAll :: Eq a => [a] -> [a] -> [a]
removeAll = undefined

everyother :: [a] -> [a]
everyother = undefined

same :: Eq a => [a] -> [a] -> [Int]
same = undefined


------------------------- Exercise 2

pairs :: [a] -> [b] -> [(a,b)]
pairs = undefined

selfpairs :: [a] -> [(a,a)]
selfpairs = undefined

pyts :: Int -> [(Int,Int,Int)]
pyts = undefined

