
------------------------- Exercise 1

doubles :: [Int] -> [Int]
doubles = undefined

odds :: [Int] -> [Int]
odds = undefined

doubleodds :: [Int] -> [Int]
doubleodds = undefined


------------------------- Exercise 2

shorts :: [String] -> [String]
shorts = undefined

squarePositives :: [Int] -> [Int]
squarePositives = undefined

oddLengthSums :: [[Int]] -> [Int]
oddLengthSums = undefined


------------------------- Exercise 3

remove :: Eq a => [a] -> a -> [a]
remove = undefined

removeAll :: Eq a => [a] -> [a] -> [a]
removeAll = undefined

numbered :: [a] -> [(Int,a)]
numbered = undefined

everyother :: [a] -> [a]
everyother = undefined

same :: Eq a => [a] -> [a] -> [Int]
same = undefined
